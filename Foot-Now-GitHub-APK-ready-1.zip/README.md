Foot Now - Android APK project

بعد رفع المشروع إلى GitHub:
Actions > Build Foot Now APK > Run workflow.
بعد نجاح البناء افتح نتيجة التشغيل ثم Artifacts ونزّل FootNow-APK.
GitHub Actions ينفذ الـworkflow على خادم، والـworkflow موجود في .github/workflows.
